import React from "react";
import '../styles/Navbar.css'
import logoImage from '../assets/images/insure-all-logo.jpg'

const Navbar = () => {
    return(
        <header className="header">
            <a href="/" className="logo">
            <img src={logoImage} alt="Logo" className="logo-img"/>
            </a>

            <nav className="navbar">
            <a href="/">Insurance Advisors</a>
            <a href="/">Services</a>
            <a href="/">Contact</a>
            <a href="/login">Login</a>
            <a href="/register">Register</a>   
            </nav>
        </header>
    )
}
export default Navbar;

// import React from "react";
// import '../styles/Navbar.css';
// import logoImage from '../assets/images/insure-all-logo.jpg';
// import { FaHeartbeat, FaShieldAlt, FaCar, FaHome } from 'react-icons/fa'; // Importing icons

// const Navbar = () => {
//     return (
//         <header className="header">
//             <a href="/" className="logo">
//                 <img src={logoImage} alt="Logo" className="logo-img" />
//             </a>

//             <nav className="navbar">
//                 <div className="dropdown">
//                     <a href="/">Insurance Advisors</a>
//                     <div className="dropdown-content">
//                         <a href="/">New Delhi</a>
//                         <a href="/">Gurgaon</a>
//                         <a href="/">Noida</a>
//                         <a href="/">Chennai</a>
//                     </div>
//                 </div>
//                 <div className="dropdown">
//                     <a href="/">Services</a>
//                     <div className="dropdown-content">
//                         <a className="dropan" href="/health-insurance"><FaHeartbeat /> Health Insurance</a>
//                         <a className="dropan" href="/life-insurance"><FaShieldAlt /> Life Insurance</a>
//                         <a className="dropan" href="/vehicle-insurance"><FaCar /> Vehicle Insurance</a>
//                         <a className="dropan" href="/home-insurance"><FaHome /> Home Insurance</a>
//                     </div>
//                 </div>
//                 <a href="/">Contact</a>
//                 <a href="/login">Login</a>
//                 <a href="/register">Register</a>
//             </nav>
//         </header>
//     );
// }

// export default Navbar;



