// import React, { useState } from 'react';
// import axios from 'axios';
// import { useNavigate, useLocation } from 'react-router-dom';
 
// const PlanTypeForm = () => {
//   const navigate = useNavigate();
//   const location = useLocation();
//   const { planType = '' } = location.state || {};
//   console.log(planType);
 
//   const [formData, setFormData] = useState({
//     // Initialize all possible fields here
//     annualIncome: '',
//     healthHistory: '',
//     smokingStatus: '',
//     hobbiesLifestyle: '',
//     medicalExamDetails: '',
//     propertyAddress: '',
//     yearBuilt: '',
//     residenceType: '',
//     squareFootage: '',
//     securitySystems: '',
//     heightWeight: '',
//     existingConditions: '',
//     primaryPhysician: '',
//     medications: '',
//     hospitalPreferences: '',
//     vin: '',
//     currentMileage: '',
//     previousClaims: '',
//     usageType: '',
//     usageFrequency: '',
//   });
 
//   const handleChange = (e) => {
//     setFormData({ ...formData, [e.target.name]: e.target.value });
//   };
 
//   const handleSubmit = (e) => {
//     e.preventDefault();
//     console.log(formData);
//     console.log.apply(planType);
//     axios.post(`http://localhost:8080/api/${planType}-insurance`, formData)
//       .then(response => {
//         alert('Details submitted successfully');
//         navigate('/customer/success-page'); // Navigate to a success page or dashboard
//       })
//       .catch(error => console.error(error));
//   };
 
//   const renderFormFields = () => {
//     switch (planType) {
//       case 'life':
//         return (
//           <>
//             <label>
//               Annual Income:
//               <select name="annualIncome" value={formData.annualIncome} onChange={handleChange} required>
//                 <option value="">Select Annual Income</option>
//                 <option value="Up to 2.9L">Up to 2.9L</option>
//                 <option value="3L to 4.9L">3L to 4.9L</option>
//                 <option value="5L to 7.9L">5L to 7.9L</option>
//                 <option value="8L to 9.9L">8L to 9.9L</option>
//                 <option value="10L to 19.9L">10L to 19.9L</option>
//                 <option value="20L and above">20L and above</option>
//               </select>
//             </label>
//             <label>
//               Health History:
//               <textarea name="healthHistory" value={formData.healthHistory} onChange={handleChange} required />
//             </label>
//             <label>
//               Smoking Status:
//               <select name="smokingStatus" value={formData.smokingStatus} onChange={handleChange} required>
//                 <option value="non-smoker">Non-Smoker</option>
//                 <option value="smoker">Smoker</option>
//               </select>
//             </label>
//             <label>
//               Hobbies and Lifestyle:
//               <textarea name="hobbiesLifestyle" value={formData.hobbiesLifestyle} onChange={handleChange} required />
//             </label>
//             <label>
//               Medical Exam Details:
//               <textarea name="medicalExamDetails" value={formData.medicalExamDetails} onChange={handleChange} required />
//             </label>
//           </>
//         );
//       case 'home':
//         return (
//           <>
//             <label>
//               Property Address:
//               <input type="text" name="propertyAddress" value={formData.propertyAddress} onChange={handleChange} required />
//             </label>
//             <label>
//               Year Built:
//               <input type="number" name="yearBuilt" value={formData.yearBuilt} onChange={handleChange} required />
//             </label>
//             <label>
//               Type of Residence:
//               <select name="residenceType" value={formData.residenceType} onChange={handleChange} required>
//                 <option value="single-family">Single-family</option>
//                 <option value="condo">Condo</option>
//                 <option value="townhouse">Townhouse</option>
//                 <option value="multi-family">Multi-family</option>
//               </select>
//             </label>
//             <label>
//               Square Footage:
//               <input type="number" name="squareFootage" value={formData.squareFootage} onChange={handleChange} required />
//             </label>
//             <label>
//               Security Systems:
//               <select name="securitySystems" value={formData.securitySystems} onChange={handleChange} required>
//                 <option value="yes">Yes</option>
//                 <option value="no">No</option>
//               </select>
//             </label>
//           </>
//         );
//       case 'health':
//         return (
//           <>
//             <label>
//               Height and Weight:
//               <input type="text" name="heightWeight" value={formData.heightWeight} onChange={handleChange} required />
//             </label>
//             <label>
//               Existing Medical Conditions:
//               <textarea name="existingConditions" value={formData.existingConditions} onChange={handleChange} required />
//             </label>
//             <label>
//               Primary Care Physician:
//               <input type="text" name="primaryPhysician" value={formData.primaryPhysician} onChange={handleChange} required />
//             </label>
//             <label>
//               Medications:
//               <textarea name="medications" value={formData.medications} onChange={handleChange} required />
//             </label>
//             <label>
//               Hospital Preferences:
//               <textarea name="hospitalPreferences" value={formData.hospitalPreferences} onChange={handleChange} required />
//             </label>
//           </>
//         );
//       case 'vehicle':
//         return (
//           <>
//             <label>
//               Vehicle Identification Number (VIN):
//               <input type="text" name="vin" value={formData.vin} onChange={handleChange} required />
//             </label>
//             <label>
//               Current Mileage:
//               <input type="number" name="currentMileage" value={formData.currentMileage} onChange={handleChange} required />
//             </label>
//             <label>
//               Previous Claims:
//               <textarea name="previousClaims" value={formData.previousClaims} onChange={handleChange} required />
//             </label>
//             <label>
//               Usage Type:
//               <select name="usageType" value={formData.usageType} onChange={handleChange} required>
//                 <option value="personal">Personal</option>
//                 <option value="commercial">Commercial</option>
//               </select>
//             </label>
//             <label>
//               Vehicle Usage Frequency:
//               <select name="usageFrequency" value={formData.usageFrequency} onChange={handleChange} required>
//                 <option value="daily">Daily</option>
//                 <option value="weekly">Weekly</option>
//                 <option value="occasional">Occasional</option>
//               </select>
//             </label>
//           </>
//         );
//       default:
//         return <p>Invalid plan type</p>;
//     }
//   };
 
//   return (
//     <div>
//       <h2>{planType ? planType.charAt(0).toUpperCase() + planType.slice(1) : 'Invalid'} Insurance Details</h2>
//       <form onSubmit={handleSubmit}>
//         {renderFormFields()}
//         <button type="submit">Submit</button>
//       </form>
//     </div>
//   );
// };
 
// export default PlanTypeForm;


// 

import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate, useLocation } from 'react-router-dom';
import './SuccessPage'

const PlanTypeForm = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const { planType = '' } = location.state || {};

    const [formData, setFormData] = useState({
        // Initialize all possible fields here
        annualIncome: '',
        healthHistory: '',
        smokingStatus: '',
        hobbiesLifestyle: '',
        medicalExamDetails: '',
        propertyAddress: '',
        yearBuilt: '',
        residenceType: '',
        squareFootage: '',
        securitySystems: '',
        heightWeight: '',
        existingConditions: '',
        primaryPhysician: '',
        medications: '',
        hospitalPreferences: '',
        vin: '',
        currentMileage: '',
        previousClaims: '',
        usageType: '',
        usageFrequency: '',
    });

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        axios.post(`http://localhost:8080/api/${planType}-insurance`, formData)
            .then(response => {
                alert('Details submitted successfully');
                navigate('/customer/success-page');
            })
            .catch(error => console.error(error));
    };

    const renderFormFields = () => {
        switch (planType) {
            case 'life':
                return (
                    <>
                        <label className="block mb-4 font-bold text-lg">
                            Annual Income:
                            <select name="annualIncome" value={formData.annualIncome} onChange={handleChange} required className="block w-full mt-1 p-2 border border-gray-400 rounded-md shadow-sm">
                                <option value="">Select Annual Income</option>
                                <option value="Up to 2.9L">Up to 2.9L</option>
                                <option value="3L to 4.9L">3L to 4.9L</option>
                                <option value="5L to 7.9L">5L to 7.9L</option>
                                <option value="8L to 9.9L">8L to 9.9L</option>
                                <option value="10L to 19.9L">10L to 19.9L</option>
                                <option value="20L and above">20L and above</option>
                            </select>
                        </label>
                        <label className="block mb-4 font-bold text-lg">
                            Health History:
                            <textarea name="healthHistory" value={formData.healthHistory} onChange={handleChange} required className="block w-full mt-1 p-2 border border-gray-400 rounded-md shadow-sm"></textarea>
                        </label>
                        <label className="block mb-4 font-bold text-lg">
                            Smoking Status:
                            <select name="smokingStatus" value={formData.smokingStatus} onChange={handleChange} required className="block w-full mt-1 p-2 border border-gray-400 rounded-md shadow-sm">
                                <option value="non-smoker">Non-Smoker</option>
                                <option value="smoker">Smoker</option>
                            </select>
                        </label>
                        <label className="block mb-4 font-bold text-lg">
                            Hobbies and Lifestyle:
                            <textarea name="hobbiesLifestyle" value={formData.hobbiesLifestyle} onChange={handleChange} required className="block w-full mt-1 p-2 border border-gray-400 rounded-md shadow-sm"></textarea>
                        </label>
                        <label className="block mb-4 font-bold text-lg">
                            Medical Exam Details:
                            <textarea name="medicalExamDetails" value={formData.medicalExamDetails} onChange={handleChange} required className="block w-full mt-1 p-2 border border-gray-400 rounded-md shadow-sm"></textarea>
                        </label>
                    </>
                );
            case 'home':
                return (
                    <>
                        <label className="block mb-4 font-bold text-lg">
                            Property Address:
                            <input type="text" name="propertyAddress" value={formData.propertyAddress} onChange={handleChange} required className="block w-full mt-1 p-2 border border-gray-400 rounded-md shadow-sm" />
                        </label>
                        <label className="block mb-4 font-bold text-lg">
                            Year Built:
                            <input type="number" name="yearBuilt" value={formData.yearBuilt} onChange={handleChange} required className="block w-full mt-1 p-2 border border-gray-400 rounded-md shadow-sm" />
                        </label>
                        <label className="block mb-4 font-bold text-lg">
                            Type of Residence:
                            <select name="residenceType" value={formData.residenceType} onChange={handleChange} required className="block w-full mt-1 p-2 border border-gray-400 rounded-md shadow-sm">
                                <option value="single-family">Single-family</option>
                                <option value="condo">Condo</option>
                                <option value="townhouse">Townhouse</option>
                                <option value="multi-family">Multi-family</option>
                            </select>
                        </label>
                        <label className="block mb-4 font-bold text-lg">
                            Square Footage:
                            <input type="number" name="squareFootage" value={formData.squareFootage} onChange={handleChange} required className="block w-full mt-1 p-2 border border-gray-400 rounded-md shadow-sm" />
                        </label>
                        <label className="block mb-4 font-bold text-lg">
                            Security Systems:
                            <select name="securitySystems" value={formData.securitySystems} onChange={handleChange} required className="block w-full mt-1 p-2 border border-gray-400 rounded-md shadow-sm">
                                <option value="yes">Yes</option>
                                <option value="no">No</option>
                            </select>
                        </label>
                    </>
                );
            case 'health':
                return (
                    <>
                        <label className="block mb-4 font-bold text-lg">
                            Height and Weight:
                            <input type="text" name="heightWeight" value={formData.heightWeight} onChange={handleChange} required className="block w-full mt-1 p-2 border border-gray-400 rounded-md shadow-sm" />
                        </label>
                        <label className="block mb-4 font-bold text-lg">
                            Existing Medical Conditions:
                            <textarea name="existingConditions" value={formData.existingConditions} onChange={handleChange} required className="block w-full mt-1 p-2 border border-gray-400 rounded-md shadow-sm"></textarea>
                        </label>
                        <label className="block mb-4 font-bold text-lg">
                            Primary Care Physician:
                            <input type="text" name="primaryPhysician" value={formData.primaryPhysician} onChange={handleChange} required className="block w-full mt-1 p-2 border border-gray-400 rounded-md shadow-sm" />
                        </label>
                        <label className="block mb-4 font-bold text-lg">
                            Medications:
                            <textarea name="medications" value={formData.medications} onChange={handleChange} required className="block w-full mt-1 p-2 border border-gray-400 rounded-md shadow-sm"></textarea>
                        </label>
                        <label className="block mb-4 font-bold text-lg">
                            Hospital Preferences:
                            <textarea name="hospitalPreferences" value={formData.hospitalPreferences} onChange={handleChange} required className="block w-full mt-1 p-2 border border-gray-400 rounded-md shadow-sm"></textarea>
                        </label>
                    </>
                );
            case 'vehicle':
                return (
                    <>
                        <label className="block mb-4 font-bold text-lg">
                            Vehicle Identification Number (VIN):
                            <input type="text" name="vin" value={formData.vin} onChange={handleChange} required className="block w-full mt-1 p-2 border border-gray-400 rounded-md shadow-sm" />
                        </label>
                        <label className="block mb-4 font-bold text-lg">
                            Current Mileage:
                            <input type="number" name="currentMileage" value={formData.currentMileage} onChange={handleChange} required className="block w-full mt-1 p-2 border border-gray-400 rounded-md shadow-sm" />
                        </label>
                        <label className="block mb-4 font-bold text-lg">
                            Previous Claims:
                            <textarea name="previousClaims" value={formData.previousClaims} onChange={handleChange} required className="block w-full mt-1 p-2 border border-gray-400 rounded-md shadow-sm"></textarea>
                        </label>
                        <label className="block mb-4 font-bold text-lg">
                            Usage Type:
                            <select name="usageType" value={formData.usageType} onChange={handleChange} required className="block w-full mt-1 p-2 border border-gray-400 rounded-md shadow-sm">
                                <option value="personal">Personal</option>
                                <option value="commercial">Commercial</option>
                            </select>
                        </label>
                        <label className="block mb-4 font-bold text-lg">
                            Vehicle Usage Frequency:
                            <select name="usageFrequency" value={formData.usageFrequency} onChange={handleChange} required className="block w-full mt-1 p-2 border border-gray-400 rounded-md shadow-sm">
                                <option value="daily">Daily</option>
                                <option value="weekly">Weekly</option>
                                <option value="occasional">Occasional</option>
                            </select>
                        </label>
                    </>
                );
            default:
                return <p>Invalid plan type</p>;
        }
    };

    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 p-6">
            <h2 className="text-3xl font-bold text-blue-700 mb-6">
                {planType ? planType.toUpperCase() : 'Invalid'} INSURANCE DETAILS
            </h2>
            <form onSubmit={handleSubmit} className="bg-white p-8 rounded-lg shadow-lg w-full max-w-lg">
                {renderFormFields()}
                <button type="submit" className="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700 w-full mt-4">
                    Submit
                </button>
            </form>
        </div>
    );
};

export default PlanTypeForm;