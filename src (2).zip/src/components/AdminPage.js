// import React from 'react';
// import { Link } from 'react-router-dom';
// import '../styles/Navbar.css'

// const AdminPage = () => (
//     <div>
//         <header className='header'>
//         <a href="/" className="logo">Logo</a>
//         <nav className='navbar'>
//                 <Link to="/admin/insurance-plans">Insurance Plans</Link>
//                 <Link to="/admin/view-clients">View Clients</Link>
//                 <Link to="/admin/approved-insurance">Approved Insurance</Link>
//                 <Link to="/admin/view-feedback">View Feedback</Link>
//                 <Link to="/admin/pending-approvals">Pending Approvals</Link>
            
//         </nav>
//         </header>
//     </div>
// );

// export default AdminPage;





import React from 'react';
import { Link } from 'react-router-dom';
import { FaRegListAlt, FaUsers, FaCheckCircle, FaRegCommentDots, FaBell } from 'react-icons/fa';

import '../styles/AdminPage.css'; // Make sure to import the CSS file

const AdminPage = () => (
    <div className="sidebar">
        <nav>
            <ul>
                <li>
                    <Link to="/admin/insurance-plans">
                        <FaRegListAlt className="icon" />
                        Insurance Plans
                    </Link>
                </li>
                <li>
                    <Link to="/admin/view-clients">
                        <FaUsers className="icon" />
                        View Clients
                    </Link>
                </li>
                <li>
                    <Link to="/admin/approved-insurance">
                        <FaCheckCircle className="icon" />
                        Approved Insurance
                    </Link>
                </li>
                <li>
                    <Link to="/admin/view-feedback">
                        <FaRegCommentDots className="icon" />
                        View Feedback
                    </Link>
                </li>
                <li>
                    <Link to="/admin/pending-approvals">
                        <FaBell className="icon" />
                        Pending Approvals
                    </Link>
                </li>
            </ul>
        </nav>
    </div>
);

export default AdminPage;