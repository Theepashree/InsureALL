// import React, { useState, useEffect } from 'react';
// import { Link } from 'react-router-dom';
// import axios from 'axios';

// const ViewPolicies = () => {
//   const [planTypes, setPlanTypes] = useState([]);

//   useEffect(() => {
//     axios.get('http://localhost:8080/api/insurance')
//       .then(response => setPlanTypes(response.data))
//       .catch(error => console.error(error));
//   }, []);

//   return (
//     <div>
//       <h1>Insurance Plans</h1>
//       <ul>
//         {planTypes.map(plan => (
//           <li key={plan.planId}>
//             <Link to={`/customer/policies/${plan.planType}`}>{plan.planType}</Link>
//           </li>
//         ))}
//       </ul>
//     </div>
//   );
// };

// export default ViewPolicies;

// import React, { useState, useEffect, useContext } from 'react';
// import { Link } from 'react-router-dom';
// import axios from 'axios';
// import { UserContext } from '../UserContext';

// const ViewPolicies = () => {
//     const [planTypes, setPlanTypes] = useState([]);
//     const { user } = useContext(UserContext);

//     useEffect(() => {
//         axios.get('http://localhost:8080/api/insurance')
//             .then(response => setPlanTypes(response.data))
//             .catch(error => console.error(error));
//     }, []);

//     return (
//         <div>
//             <h1>Insurance Plans</h1>
//             <ul>
//                 {planTypes.map(plan => (
//                     <li key={plan.planId}>
//                         <Link to={`/customer/policies/${plan.planType}`} state={{ userName: user.userName }}>
//                             {plan.planType}
//                         </Link>
//                     </li>
//                 ))}
//             </ul>
//         </div>
//     );
// };

// export default ViewPolicies;

// import React, { useState, useEffect, useContext } from 'react';
// import { Link } from 'react-router-dom';
// import axios from 'axios';
// import { UserContext } from '../UserContext';

// const ViewPolicies = () => {
//     const [planTypes, setPlanTypes] = useState([]);
//     const { user } = useContext(UserContext);

//     useEffect(() => {
//         axios.get('http://localhost:8080/api/insurance')
//             .then(response => setPlanTypes(response.data))
//             .catch(error => console.error(error));
//     }, []);

//     return (
//         <div>
//             <h1>Insurance Plans</h1>
//             <ul>
//                 {planTypes.map(plan => (
//                     <li key={plan.planId}>
//                         <Link to={`/customer/policies/${plan.planType}`} state={{ userName: user.userName }}>
//                             {plan.planType}
//                         </Link>
//                     </li>
//                 ))}
//             </ul>
//         </div>
//     );
// };

// export default ViewPolicies;

// import React, { useState, useEffect, useContext } from 'react';
// import { Link } from 'react-router-dom';
// import axios from 'axios';
// import { UserContext } from '../UserContext';

// const ViewPolicies = () => {
//     const [planTypes, setPlanTypes] = useState([]);
//     const { user } = useContext(UserContext);

//     useEffect(() => {
//         axios.get('http://localhost:8080/api/insurance')
//             .then(response => setPlanTypes(response.data))
//             .catch(error => console.error(error));
//     }, []);

//     return (
//         <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 p-6">
//             <h1 className="text-3xl font-bold text-blue-700 mb-6">Insurance Plans</h1>
//             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
//                 {planTypes.map(plan => (
//                     <div key={plan.planId} className="bg-white p-4 rounded-lg shadow-lg flex flex-col items-center">
//                         <img 
//                             src={`path/to/image/${plan.planType}.jpg`} 
//                             alt={`${plan.planType}`} 
//                             className="w-full h-48 object-cover rounded-t-lg mb-4" 
//                         />
//                         <Link 
//                             to={`/customer/policies/${plan.planType}`} 
//                             state={{ userName: user.userName }}
//                             className="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700"
//                         >
//                             {plan.planType}
//                         </Link>
//                     </div>
//                 ))}
//             </div>
//         </div>
//     );
// };

// export default ViewPolicies;
import React, { useState, useEffect, useContext } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { UserContext } from '../UserContext';
import '../styles/ViewPolicies.css'; // Import the CSS file for custom styles
import '../styles/Navbar.css';
import Footer from './Footer';
import logoImage from '../assets/images/insure-all-logo.jpg'


// Import images
import healthIcon from '../assets/images/icon03.png';
import homeIcon from '../assets/images/icon04.png';
import lifeIcon from '../assets/images/lifeicon.jpg';
import vehicleIcon from '../assets/images/icon01.png';

const ViewPolicies = () => {
    const [planTypes, setPlanTypes] = useState([]);
    const { user } = useContext(UserContext);

    useEffect(() => {
        axios.get('http://localhost:8080/api/insurance')
            .then(response => setPlanTypes(response.data))
            .catch(error => console.error(error));
    }, []);

    // Function to get the image path based on plan type
    const getImagePath = (planType) => {
        switch (planType.toLowerCase()) {
            case 'health':
                return healthIcon;
            case 'home':
                return homeIcon;
            case 'life':
                return lifeIcon;
            case 'vehicle':
                return vehicleIcon;
            default:
                return ''; // Fallback to a default image if needed
        }
    };

    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 p-6">

<header className='header'>
                <a href="/" className="logo">
                <img src={logoImage} alt="Logo" className="logo-img"/>
                </a>
                <nav className='navbar'>
                    <Link to="/customer/edit-profile">Edit Profile</Link>
                    <Link to="/customer/view-policy">View Policy</Link>
                    <Link to="/customer/premium-calculator">Premium Calculator</Link>
                    <Link to="/customer/policy-status">Policy Status</Link>
                    <Link to="/customer/give-feedback">Give Feedback</Link>
                </nav>
            </header> 

            <h1 className="text-3xl font-bold text-blue-700 mb-6">INSURANCE PLANS</h1>
            <div className="container-ViewPolicies">
                {planTypes.map((plan,index) => (
                    <div key={plan.planId} className="card">
                        <img
                            src={getImagePath(plan.planType)}
                            alt={`${plan.planType}`}
                            className={index===2 ? 'reduced-width': ''}
                        />
                        <Link
                            to={`/customer/policies/${plan.planType}`}
                            state={{ userName: user.userName }}
                        >
                            {plan.planType.toUpperCase()}
                        </Link>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default ViewPolicies;



