// import React, { useState } from 'react';
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';

// axios.defaults.baseURL = 'http://localhost:8080';

// function Login() {
//     const [userName, setUserName] = useState('');
//     const [password, setPassword] = useState('');
//     const [msg, setMsg] = useState('');
//     const navigate = useNavigate();

//     const handleSubmit = async (e) => {
//         e.preventDefault();
//         try {
//             const response = await axios.post('/api/login', { userName, password });
//            // response.data.role
//             if (response.data.role === 'admin') {
//                 navigate('/admin');
//             } 
//             else if(response.data.role === 'customer') {
//                 navigate('/customer');
//             } 
//             else {
//                 navigate('/dashboard'); // Update this to the actual user dashboard route
//             }
//         } catch (error) {
//             setMsg('Invalid username or password');
//         }
//     };

//     return (
//         <div>
//             <h2>Login</h2>
//             <form onSubmit={handleSubmit}>
//                 <div>
//                     <label>Username</label>
//                     <input type="text" value={userName} onChange={(e) => setUserName(e.target.value)} required />
//                 </div>
//                 <div>
//                     <label>Password</label>
//                     <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
//                 </div>
//                 {msg && <p>{msg}</p>}
//                 <button type="submit">Login</button>
//             </form>
//         </div>
//     );
// }

// export default Login;

import React, { useState, useContext } from 'react';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';
import { UserContext } from '../UserContext';
import '../styles/Login.css'
import { FaUser,FaLock } from "react-icons/fa";

axios.defaults.baseURL = 'http://localhost:8080';

function Login() {
    const [userName, setUserName] = useState('');
    const [password, setPassword] = useState('');
    const [msg, setMsg] = useState('');
    const { setUser } = useContext(UserContext);
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('/api/login', { userName, password });
            if (response.data.role === 'admin') {
                setUser({ userName, role: 'admin' });
                navigate('/admin');
            } else if (response.data.role === 'customer') {
                setUser({ userName, role: 'customer' });
                navigate('/customer');
            } else {
                setUser({ userName, role: 'user' });
                navigate('/dashboard'); // Update this to the actual user dashboard route
            }
        } catch (error) {
            setMsg('Invalid username or password');
        }
    };

    return (
        <div className="login-container" style={{color:"black"}}>
            <div className='wrapper' style={{color:"black"}}>
            <h1>Login</h1>
            <form onSubmit={handleSubmit} style={{color:"black"}}>
                <div className='input-box'>
                    {/* <label>Username</label> */}
                    <input type="text" placeholder='Username' value={userName} onChange={(e) => setUserName(e.target.value)} required />
                    <FaUser className='icon'/>
                </div>
                <div className='input-box' style={{color:"black"}}>
                    {/* <label>Password</label> */}
                    <input style={{color:"black"}} type="password" placeholder='Password' value={password} onChange={(e) => setPassword(e.target.value)} required />
                    <FaLock className='icon'/>
                </div>

                <div className='remember-forgot'>
                    <label><input type='checkbox'/>Remember me</label>
                    <a href='#'>Forgot password?</a>
                </div>
                {msg && <p>{msg}</p>}
                <button type="submit">Login</button>
                <div className='register-link'>
                    <p>Don't have an account? <Link to='/Register'>Register</Link></p>
                </div>
            </form>
            </div>
        </div>
    );
}

export default Login;
