import React from 'react'

const LifeServices = () => {
  return (
    <div>
      
    </div>
  )
}

export default LifeServices;
