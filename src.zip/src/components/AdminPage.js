import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/Navbar.css'

const AdminPage = () => (
    <div>
        <header className='header'>
        <a href="/" className="logo">Logo</a>
        <nav className='navbar'>
                <Link to="/admin/insurance-plans">Insurance Plans</Link>
                <Link to="/admin/view-clients">View Clients</Link>
                <Link to="/admin/approved-insurance">Approved Insurance</Link>
                <Link to="/admin/view-feedback">View Feedback</Link>
                <Link to="/admin/pending-approvals">Pending Approvals</Link>
            
        </nav>
        </header>
    </div>
);

export default AdminPage;


