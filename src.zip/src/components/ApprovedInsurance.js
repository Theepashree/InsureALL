import React, { useEffect, useState } from 'react';
import axios from 'axios';

const ApprovedInsurance = () => {
    const [clients, setClients] = useState([]);

    useEffect(() => {
        fetchApprovedClients();
    }, []);

    const fetchApprovedClients = async () => {
        try {
            const response = await axios.get('/api/appliedPolicies/approved');
            setClients(response.data);
        } catch (error) {
            console.error('Error fetching approved clients', error);
        }
    };

    return (
        <div>
            <h2>Approved Clients</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Policy Name</th>
                        <th>Plan Type</th>
                        <th>Customer Name</th>
                        <th>Term</th>
                        <th>Period</th>
                        <th>Current Date</th>
                        <th>Next Payment Date</th>
                        <th>Term Amount</th>
                        <th>Coverage Amount</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    {clients.map((client) => (
                        <tr key={client.appliedPolicyId}>
                            <td>{client.appliedPolicyId}</td>
                            <td>{client.policyName}</td>
                            <td>{client.planType}</td>
                            <td>{client.customerName}</td>
                            <td>{client.term}</td>
                            <td>{client.period}</td>
                            <td>{client.currentDate}</td>
                            <td>{client.nextPaymentDate}</td>
                            <td>{client.termAmount}</td>
                            <td>{client.coverageAmount}</td>
                            <td>{client.status}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default ApprovedInsurance;
