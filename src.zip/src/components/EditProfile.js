// import React, { useState, useEffect, useContext } from 'react';
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';
// import { UserContext } from '../UserContext';

// const EditProfile = () => {
//     const { user, setUser } = useContext(UserContext);
//     const [formData, setFormData] = useState({
//         firstName: '',
//         lastName: '',
//         email: '',
//         userName: '',
//         password: '',
//     });

//     const navigate = useNavigate();

//     useEffect(() => {
//         if (user) {
//             setFormData({
//                 firstName: user.firstName,
//                 lastName: user.lastName,
//                 email: user.email,
//                 userName: user.userName,
//                 password: '',
//             });
//         }
//     }, [user]);

//     const handleChange = (e) => {
//         setFormData({ ...formData, [e.target.name]: e.target.value });
//     };

//     const handleSubmit = (e) => {
//         e.preventDefault();
//         console.log(user.userId);
//         console.log(user.userName);
//         console.log(user.firstName);
//         axios.put(`http://localhost:8080/api/users/${user.userId}`, formData)
//             .then(response => {
//                 setUser(response.data);
//                 alert('Profile updated successfully');
//                 navigate('/customer');
//             })
//             .catch(error => console.error('There was an error updating the profile!', error));
//     };

//     return (
//         <div>
//             <h2>Edit Profile</h2>
//             <form onSubmit={handleSubmit}>
//                 <label>
//                     First Name:
//                     <input type="text" name="firstName" value={formData.firstName} onChange={handleChange} required />
//                 </label>
//                 <label>
//                     Last Name:
//                     <input type="text" name="lastName" value={formData.lastName} onChange={handleChange} required />
//                 </label>
//                 <label>
//                     Email:
//                     <input type="email" name="email" value={formData.email} onChange={handleChange} required />
//                 </label>
//                 <label>
//                     User Name:
//                     <input type="text" name="userName" value={formData.userName} onChange={handleChange} required />
//                 </label>
//                 <label>
//                     Password:
//                     <input type="password" name="password" value={formData.password} onChange={handleChange} required />
//                 </label>
//                 <button type="submit">Update</button>
//             </form>
//         </div>
//     );
// };

// export default EditProfile;

import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { UserContext } from '../UserContext';

const EditProfile = () => {
    const { user, setUser } = useContext(UserContext);
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        email: '',
        userName: '',
        password: '',
    });

    const navigate = useNavigate();

    useEffect(() => {
        if (user) {
            axios.get(`/api/users/${user.userName}`)
                .then(response => {
                    setFormData({
                        firstName: response.data.firstName,
                        lastName: response.data.lastName,
                        email: response.data.email,
                        userName: response.data.userName,
                        password: '',
                    });
                })
                .catch(error => console.error('Error fetching user details:', error));
        }
    }, [user]);

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        axios.put(`/api/users/${user.userName}`, formData)
            .then(response => {
                setUser(response.data);
                alert('Profile updated successfully');
                navigate('/customer');
            })
            .catch(error => console.error('There was an error updating the profile!', error));
    };

    return (
        <div>
            <h2>Edit Profile</h2>
            <form onSubmit={handleSubmit}>
                <label>
                    First Name:
                    <input type="text" name="firstName" value={formData.firstName} onChange={handleChange} required />
                </label>
                <label>
                    Last Name:
                    <input type="text" name="lastName" value={formData.lastName} onChange={handleChange} required />
                </label>
                <label>
                    Email:
                    <input type="email" name="email" value={formData.email} onChange={handleChange} required />
                </label>
                <label>
                    User Name:
                    <input type="text" name="userName" value={formData.userName} onChange={handleChange} required />
                </label>
                <label>
                    Password:
                    <input type="password" name="password" value={formData.password} onChange={handleChange} required />
                </label>
                <button type="submit">Update</button>
            </form>
        </div>
    );
};

export default EditProfile;
