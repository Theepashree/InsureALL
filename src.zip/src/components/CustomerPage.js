// import React from 'react';
// import { Link } from 'react-router-dom';

// const CustomerPage = () => (
//   <div>
//     <nav>
//       <ul>
//         <li><Link to="/customer/edit-profile">Edit Profile</Link></li>
//         <li><Link to="/customer/view-policy">View Policy</Link></li>
//         <li><Link to="/customer/premium-calculator">Premium Calculator</Link></li>
//         <li><Link to="/customer/policy-status">Policy Status</Link></li>
//         <li><Link to="/customer/give-feedback">Give Feedback</Link></li>
//       </ul>
//     </nav>
//   </div>
// );

// export default CustomerPage;

import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { UserContext } from '../UserContext';
import '../styles/Navbar.css'

const CustomerPage = () => {
    const { user } = useContext(UserContext);

    return (
        <div>
             <header className='header'>
             <a href="/" className="logo">Logo</a>
            {/* <h2>Welcome, {user.userName}</h2> */}
            <nav className='navbar'>
                    <Link to="/customer/edit-profile">Edit Profile</Link>
                    <Link to="/customer/view-policy">View Policy</Link>
                    <Link to="/customer/premium-calculator">Premium Calculator</Link>
                    <Link to="/customer/policy-status">Policy Status</Link>
                    <Link to="/customer/give-feedback">Give Feedback</Link>
            </nav>
            </header>
        </div>
    );
};

export default CustomerPage;
