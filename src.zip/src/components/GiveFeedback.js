import React, { useState } from 'react';
import axios from 'axios';
 
const GiveFeedback = () => {
  const [customerName, setCustomerName] = useState('');
  const [feedback, setFeedback] = useState('');
 
  const handleSubmit = async () => {
    if (feedback.length > 1000) {
      alert('Feedback must be less than 1000 characters.');
      return;
    }
 
    try {
      const response = await axios.post('/api/feedback', {
        customerName,
        comments: feedback
      });
      alert('Feedback submitted successfully!');
      setCustomerName(''); // Reset customer name field after successful submission
      setFeedback(''); // Reset feedback field after successful submission
    } catch (error) {
      console.error('Error submitting feedback:', error);
      alert('Failed to submit feedback.');
    }
  };
 
  const handleReset = () => {
    setCustomerName('');
    setFeedback('');
  };
 
  return (
    <div>
      <h3>Please submit your feedback (Maximum length - 1000 characters only)</h3>
      <label htmlFor="customerName">Your Name:</label>
      <input
        type="text"
        value={customerName}
        onChange={(e) => setCustomerName(e.target.value)}
        placeholder="Enter your name"
      />
      <textarea
        value={feedback}
        onChange={(e) => setFeedback(e.target.value)}
        placeholder="Type your feedback here..."
        maxLength="1000"
      />
      <button onClick={handleSubmit}>Submit Feedback</button>
      <button onClick={handleReset}>Reset</button>
    </div>
  );
};
 
export default GiveFeedback;