import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { UserContext } from '../UserContext';

const PolicyStatus = () => {
    const { user } = useContext(UserContext);
    const [policies, setPolicies] = useState([]);

    useEffect(() => {
        axios.get(`http://localhost:8080/api/appliedPolicies/username?userName=${user.userName}`)
            .then(response => setPolicies(response.data))
            .catch(error => console.error('Error fetching policies:', error));
    }, [user.userName]);

    return (
        <div>
            <h2>Policy Status for {user.userName}</h2>
            <table>
                <thead>
                    <tr>
                        <th>Policy Name</th>
                        <th>Plan Type</th>
                        <th>Customer Name</th>
                        <th>Term</th>
                        <th>Period</th>
                        <th>Next Payment Date</th>
                        <th>Term Amount</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    {policies.map(policy => (
                        <tr key={policy.appliedPolicyId}>
                            <td>{policy.policyName}</td>
                            <td>{policy.planType}</td>
                            <td>{policy.customerName}</td>
                            <td>{policy.term}</td>
                            <td>{policy.period}</td>
                            <td>{policy.nextPaymentDate}</td>
                            <td>{policy.termAmount}</td>
                            <td>{policy.status}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default PolicyStatus;
