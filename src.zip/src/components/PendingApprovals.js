// import React, { useEffect, useState } from 'react';
// import axios from 'axios';

// const PendingApprovals = () => {
//     const [clients, setClients] = useState([]);

//     useEffect(() => {
//         fetchPendingClients();
//     }, []);

//     const fetchPendingClients = async () => {
//         try {
//             const response = await axios.get('/api/appliedPolicies/pending');
//             setClients(response.data);
//         } catch (error) {
//             console.error('Error fetching pending clients', error);
//         }
//     };

//     const handleApprove = async (id) => {
//         try {
//             await axios.put(`/api/appliedPolicies/${id}/approve`);
//             fetchPendingClients(); // Refresh the list
//         } catch (error) {
//             console.error('Error approving policy', error);
//         }
//     };

//     const handleReject = async (id) => {
//         try {
//             await axios.put(`/api/appliedPolicies/${id}/reject`);
//             fetchPendingClients(); // Refresh the list
//         } catch (error) {
//             console.error('Error rejecting policy', error);
//         }
//     };

//     return (
//         <div>
//             <h2>Pending Approvals</h2>
//             <table>
//                 <thead>
//                     <tr>
//                         <th>ID</th>
//                         <th>Policy Name</th>
//                         <th>Plan Type</th>
//                         <th>Customer Name</th>
//                         <th>Term</th>
//                         <th>Period</th>
//                         <th>Current Date</th>
//                         <th>Next Payment Date</th>
//                         <th>Term Amount</th>
//                         <th>Coverage Amount</th>
//                         <th>Status</th>
//                         <th>Actions</th>
//                     </tr>
//                 </thead>
//                 <tbody>
//                     {clients.map((client) => (
//                         <tr key={client.appliedPolicyId}>
//                             <td>{client.appliedPolicyId}</td>
//                             <td>{client.policyName}</td>
//                             <td>{client.planType}</td>
//                             <td>{client.customerName}</td>
//                             <td>{client.term}</td>
//                             <td>{client.period}</td>
//                             <td>{client.currentDate}</td>
//                             <td>{client.nextPaymentDate}</td>
//                             <td>{client.termAmount}</td>
//                             <td>{client.coverageAmount}</td>
//                             <td>{client.status}</td>
//                             <td>
//                                 <button onClick={() => handleApprove(client.appliedPolicyId)}>Approve</button>
//                                 <button onClick={() => handleReject(client.appliedPolicyId)}>Reject</button>
//                             </td>
//                         </tr>
//                     ))}
//                 </tbody>
//             </table>
//         </div>
//     );
// };

// export default PendingApprovals;

import React, { useEffect, useState } from 'react';
   import { useNavigate } from 'react-router-dom';
   import axios from 'axios';

   const PendingApprovals = () => {
       const [clients, setClients] = useState([]);
       const navigate = useNavigate(); // For navigation

       useEffect(() => {
           fetchPendingClients();
       }, []);

       const fetchPendingClients = async () => {
           try {
               const response = await axios.get('/api/appliedPolicies/pending');
               setClients(response.data);
           } catch (error) {
               console.error('Error fetching pending clients', error);
           }
       };

       const handleApprove = async (id) => {
           try {
               await axios.put(`/api/appliedPolicies/${id}/approve`);
               fetchPendingClients(); // Refresh the list
           } catch (error) {
               console.error('Error approving policy', error);
           }
       };

       const handleReject = async (id) => {
           try {
               await axios.put(`/api/appliedPolicies/${id}/reject`);
               fetchPendingClients(); // Refresh the list
           } catch (error) {
               console.error('Error rejecting policy', error);
           }
       };

       const handleViewDocuments = (id) => {
           navigate(`/admin/view-documents/${id}`); // Navigate to the view documents page
       };

       return (
           <div>
               <h2>Pending Approvals</h2>
               <table>
                   <thead>
                       <tr>
                           <th>ID</th>
                           <th>Policy Name</th>
                           <th>Plan Type</th>
                           <th>Customer Name</th>
                           <th>Term</th>
                           <th>Period</th>
                           <th>Current Date</th>
                           <th>Next Payment Date</th>
                           <th>Term Amount</th>
                           <th>Coverage Amount</th>
                           <th>Status</th>
                           <th>Actions</th>
                       </tr>
                   </thead>
                   <tbody>
                       {clients.map((client) => (
                           <tr key={client.appliedPolicyId}>
                               <td>{client.appliedPolicyId}</td>
                               <td>{client.policyName}</td>
                               <td>{client.planType}</td>
                               <td>{client.customerName}</td>
                               <td>{client.term}</td>
                               <td>{client.period}</td>
                               <td>{client.currentDate}</td>
                               <td>{client.nextPaymentDate}</td>
                               <td>{client.termAmount}</td>
                               <td>{client.coverageAmount}</td>
                               <td>{client.status}</td>
                               <td>
                                   <button onClick={() => handleApprove(client.appliedPolicyId)}>Approve</button>
                                   <button onClick={() => handleReject(client.appliedPolicyId)}>Reject</button>
                                   <button onClick={() => handleViewDocuments(client.appliedPolicyId)}>View Documents</button>
                               </td>
                           </tr>
                       ))}
                   </tbody>
               </table>
           </div>
       );
   };

   export default PendingApprovals;

